from __future__ import unicode_literals
from django.db import models
from ..users.models import User, UserManager
# Here I import the models from the users app to use them
# as a foreign key in the Trip class
from datetime import datetime
import bcrypt
import re

class TripManager(models.Manager):
     # Manages the trip class when adding a new trip into the database
    def validator(self, postData):
        errors = {}
        if len(postData['destination']) < 1:
            errors['destinationlength'] = "Destination field cannot be blank."
        if len(postData['description']) < 1:
            errors['descriptionlength'] = "Description field cannot be blank."
        if len(postData['start_date']) < 1:
            errors['startlength'] = "Date fields cannot be blank."
        elif postData['start_date'] < str(datetime.now()):
            errors['paststart'] = "Start date must be in the future."
        if len(postData['end_date']) < 1:
            errors['endlength'] = "Date fields cannot be blank."
        elif postData['end_date'] < str(datetime.now()):
            errors['pastend'] = "End date must be in the future."
        if postData['start_date'] > postData['end_date']:
            errors['dateerror'] = "Start date must be before the end date."
        return errors

    # This is the individual trip class
    # Foreign key pointing to the User class (User App)
    # Imported at top
class Trip(models.Model):
    destination = models.CharField(max_length = 255)
    description = models.TextField()
    start_date = models.DateTimeField()
    end_date = models.DateTimeField()
    created_at = models.DateTimeField(auto_now_add = True)
    updated_at = models.DateTimeField(auto_now = True)
    users = models.ManyToManyField(User, related_name = "trips")
    objects = TripManager()


